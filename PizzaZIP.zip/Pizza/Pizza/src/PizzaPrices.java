import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PizzaPrices {
    public static final double PEPPERONI_PRICE = 15.0;
    public static final double MUSHROOM_PRICE = 14.0;
    public static final double EXTRA_CHEESE_PRICE = 13.0;
}